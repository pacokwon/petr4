#include <core.p4>
#include <v1model.p4>
@command_line("--loopsUnroll")

header S {
    bit<8> t;
}

header O1 {
    bit<8> data;
}
header O2 {
    bit<16> data;
}

header_union U {
    O1 byte;
    O2 short;
}

struct headers {
    S base;
    U[2] u;
}

struct metadata {}

parser ParserImpl(packet_in packet,
                  out headers hdr,
                  inout metadata meta,
                  inout standard_metadata_t standard_metadata)
{
    state start {
        packet.extract(hdr.u.next.byte);
        packet.extract(hdr.u.next.short);
        transition accept;
    }
}

control ingress(inout headers hdr,
                inout metadata meta,
                inout standard_metadata_t standard_metadata) {
    apply {}
}

control egress(inout headers hdr,
               inout metadata meta,
               inout standard_metadata_t standard_metadata)
{ apply {} }

control DeparserImpl(packet_out packet, in headers hdr) {
    apply {
        packet.emit(hdr.u);
    }
}

control verifyChecksum(inout headers hdr, inout metadata meta) {
    apply { }
}

control computeChecksum(inout headers hdr, inout metadata meta) {
    apply { }
}

V1Switch(ParserImpl(),
         verifyChecksum(),
         ingress(),
         egress(),
         computeChecksum(),
         DeparserImpl()) main;
