/*
Copyright 2016 VMware, Inc.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/
extern void f(in bit x);
extern void g<T>();

control p()
{
    apply {
        f(); // not enough arguments
        f(1w1, 1w0); // too many arguments
        f<bit>(1w0); // too many type arguments
        g<bit, bit>(); // too many type arguments
    }
}
