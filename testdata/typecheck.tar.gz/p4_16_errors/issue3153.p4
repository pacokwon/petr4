const bool b = +false;
