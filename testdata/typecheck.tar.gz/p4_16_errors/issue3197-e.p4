void f() {
	f();
}
