
struct S { S x; }
